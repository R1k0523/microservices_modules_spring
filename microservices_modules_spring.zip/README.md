## (WIP) Попытка автоматизировать сборку микросервисов на Spring Boot
2 модуля на Spring Boot. Каждый должен являться микросервисом.
Запустить docker compose
```
docker-compose up
```
