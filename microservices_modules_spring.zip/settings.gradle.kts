rootProject.name = "microservices_example"
include(
    "common",
    "test",
)
